// Top-level build file where you can add configuration options common to all sub-projects/modules.
buildscript {
    extra.apply {
        set("room_version", "2.5.2") // New version 2.6.0 will break ksp
    }
}

plugins {
    id("com.android.application") version "8.1.3" apply false
    // Changed to version 1.8.21
    id("org.jetbrains.kotlin.android") version "1.8.21" apply false
}