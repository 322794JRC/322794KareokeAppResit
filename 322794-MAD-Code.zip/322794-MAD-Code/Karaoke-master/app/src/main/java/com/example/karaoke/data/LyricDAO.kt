package com.example.karaoke.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Update
import androidx.room.Delete
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao //Creates the Dao (Data Access Object)
interface LyricDAO {
    @Insert(onConflict = OnConflictStrategy.IGNORE) //Inserts a new lyric into the database.
    suspend fun insert(lyric: Lyric)

    @Update //Updates a lyric already located within the database.
    suspend fun update(lyric: Lyric)

    @Delete //Deletes a lyric located within the database.
    suspend fun delete (lyric: Lyric)

    @Query("SELECT * FROM lyric_table ORDER BY songTitle ASC")
    fun getAllLyricsByTitle():Flow<List<Lyric>>
}