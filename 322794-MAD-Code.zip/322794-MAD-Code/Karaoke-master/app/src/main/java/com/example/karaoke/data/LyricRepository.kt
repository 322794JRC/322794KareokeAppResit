package com.example.karaoke.data

import kotlinx.coroutines.flow.Flow

interface LyricRepository {
    val allLyrics: Flow<List<Lyric>> //Lists all of the lyrics stored within the database.

    suspend fun getLyricBySong(songName: String) //Gets a lyric by using the associated track name.

    suspend fun insertLyric(lyric: Lyric) //Inserts a lyric to the database.

    suspend fun deleteLyric(lyric: Lyric) //Deletes a lyric within the database.

    suspend fun updateLyric(lyric: Lyric) //Updates the lyrics within the database.
}