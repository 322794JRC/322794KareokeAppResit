package com.example.karaoke.data

import kotlinx.coroutines.flow.Flow

class OfflineLyricStorage(private val lyricDAO: LyricDAO) : LyricRepository {

    override val allLyrics: Flow<List<Lyric>> = lyricDAO.getAllLyricsByTitle()

    override suspend fun getLyricBySong(songName: String) {}

    override suspend fun insertLyric(lyric: Lyric) = lyricDAO.insert(lyric)

    override suspend fun deleteLyric(lyric: Lyric) = lyricDAO.delete(lyric)

    override suspend fun updateLyric(lyric: Lyric) = lyricDAO.update(lyric)
}