package com.example.karaoke.data

import androidx.room.Database
import androidx.room.RoomDatabase
import android.content.Context
import androidx.room.Room


//Creates the database which will be used to store lyrics within the app.
@Database(entities = [Lyric::class], version = 1, exportSchema = false)
abstract class lyricDatabase : RoomDatabase() {

    abstract fun lyricDao(): LyricDAO //returns this allowing for the database to know about the DAO.

    companion object{
        @Volatile
        private var Instance: lyricDatabase? = null //Keeps a reference to the database to prevent multiple instances being opened.

        fun getDatabase(context: Context): lyricDatabase {
            return Instance ?: synchronized(this){
                Room.databaseBuilder(context, lyricDatabase::class.java, "lyric_database")
                    .fallbackToDestructiveMigration()
                    .build()
                    .also {Instance = it}
            }
        }
    }
}