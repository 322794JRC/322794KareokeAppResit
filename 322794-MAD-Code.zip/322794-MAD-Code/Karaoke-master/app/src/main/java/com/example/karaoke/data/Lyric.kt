package com.example.karaoke.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Lyric_Table") //Creates an entity table to store the Lyrics under
data class Lyric(
    @PrimaryKey(autoGenerate = true) //Automatically generates an ID as the primary key per lyric
    val lyricID: Int = 0, //The Primary Key for each Lyric within the Database.
    val songTitle: String, //Identifier for the title of the song.
    val songArtist: String, //Identifier for the artist of the song.
    val lyricStore: String //Stores the lyrics for the chosen song.
)
